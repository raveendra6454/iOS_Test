import UIKit

let arr:[String] = ["one","two","three","four","five","six","seven","eight","nine","ten"]

//Print out array in alphabetical order
let alphaBeticlOrder = arr.sorted()
print(alphaBeticlOrder)

//Print out the array in reverse numerical order
let reverseOrder = arr.sorted {$0 > $1}
print(reverseOrder)

//Print out all the array elements that starts with the letter "t"
let tWords = arr.filter{$0.hasPrefix("t") }
print(tWords)

//Print out a dictionary of elements grouped by the first letter
let groupWords = Dictionary(grouping: arr) {$0.first ?? Character("") }
print(groupWords)



let dict = [1:"one", 2:"two", 3:"three", 4:"four", 5:"five", 6:"six", 7:"seven", 8:"eight", 9:"nine", 10:"ten", 11:"eleven", 12:"twelve", 13:"thirteen"]

// Print out the keys of all the odd numbered entries in descending order
let descendingOrderOddKeys = dict.filter { $0.key % 2 != 0 }.keys.sorted(by: >)
print(descendingOrderOddKeys)

// Print out the values of all even numbered entries that start with the letter 't'
let evenNumbersWithT = dict.filter { $0.key % 2 == 0 && $0.value.hasPrefix("t") }.values
print(evenNumbersWithT)

// Print out all the values that are multiples of 3
let multipleValuesOf3 = dict.filter { $0.value.count % 3 == 0 }.values
print(multipleValuesOf3)



enum RomanAlphabet: Int, CaseIterable {
  case I=1, V=5, X=10, L=50, C=100, D=500, M=1000, W=5000, Y=10000
}

var result = ""
var remainingNumber = 12345
    
for romanCase in RomanAlphabet.allCases.sorted(by: { $0.rawValue > $1.rawValue }) {
    while remainingNumber >= romanCase.rawValue {
        result += "\(romanCase)"
        remainingNumber -= romanCase.rawValue
    }
}
print(result)


protocol Animal {
    var name: String { get }
    var color: String { get }
    var numberOfLegs: Int { get }
    var numberOfWings: Int { get }
    var hasTail: Bool { get }

    func walk(distance: Double) throws
    func fly(distance: Double) throws
    func swim(distance: Double) throws
}

extension Animal {
    func walk(distance: Double) throws {
        guard numberOfLegs > 0 else {
            throw AnimalErrorState.cannotWalk
        }
        print("\(name) is walking \(distance) meters.")
    }

    func fly(distance: Double) throws {
        guard numberOfWings > 0 else {
            throw AnimalErrorState.cannotFly
        }
        print("\(name) is flying \(distance) meters.")
    }

    func swim(distance: Double) throws {
        guard hasTail else {
            throw AnimalErrorState.cannotSwim
        }
        print("\(name) is swimming \(distance) meters.")
    }
}

enum AnimalErrorState: Error {
    case cannotWalk
    case cannotFly
    case cannotSwim
}


import XCTest

class AnimalTests: XCTestCase {

    func testAnimalConstraints() {
        // Valid Bird with 2 legs and 2 wings
        let validBird = Bird(name: "Sparrow", color: "Brown", numberOfLegs: 2, numberOfWings: 2, hasTail: true)
        XCTAssertNoThrow(try validBird.walk(distance: 5))
        XCTAssertNoThrow(try validBird.fly(distance: 10))
        XCTAssertNoThrow(try validBird.swim(distance: 3)) // Should be allowed for all animals
        
        // Invalid Bird with 3 legs (odd number)
        let invalidLegsBird = Bird(name: "InvalidBird", color: "Red", numberOfLegs: 3, numberOfWings: 2, hasTail: true)
        XCTAssertThrowsError(try invalidLegsBird.walk(distance: 5)) { error in
            XCTAssertEqual(error as? AnimalError, AnimalError.invalidNumberOfLegs)
        }
        
        // Invalid Bird with 1 wing
        let invalidWingsBird = Bird(name: "InvalidBird", color: "Blue", numberOfLegs: 2, numberOfWings: 1, hasTail: true)
        XCTAssertThrowsError(try invalidWingsBird.fly(distance: 10)) { error in
            XCTAssertEqual(error as? AnimalError, AnimalError.invalidNumberOfWings)
        }
        
        // Invalid Bird with 9 legs (more than 8)
        let invalidLegsBirdCount = Bird(name: "InvalidBird", color: "Red", numberOfLegs: 9, numberOfWings: 2, hasTail: true)
        XCTAssertThrowsError(try invalidLegsBirdCount.walk(distance: 5)) { error in
            XCTAssertEqual(error as? AnimalError, AnimalError.invalidNumberOfLegs)
        }
        
        // Invalid Bird with 7 wings (more than 6)
        let invalidWingsBirdCount = Bird(name: "InvalidBird", color: "Blue", numberOfLegs: 2, numberOfWings: 7, hasTail: true)
        XCTAssertThrowsError(try invalidWingsBirdCount.fly(distance: 10)) { error in
            XCTAssertEqual(error as? AnimalError, AnimalError.invalidNumberOfWings)
        }
        
        // Invalid Bird with negative legs
        let negativeLegsBird = Bird(name: "InvalidBird", color: "Yellow", numberOfLegs: -2, numberOfWings: 2, hasTail: true)
        XCTAssertThrowsError(try negativeLegsBird.walk(distance: 5)) { error in
            XCTAssertEqual(error as? AnimalError, AnimalError.negativeNumberOfLegs)
        }
    }
}

// Example Animal implementation with additional constraints
struct Bird: Animal {
    var name: String
    var color: String
    var numberOfLegs: Int
    var numberOfWings: Int
    var hasTail: Bool

    init(name: String, color: String, numberOfLegs: Int, numberOfWings: Int, hasTail: Bool) {
        self.name = name
        self.color = color

        // Ensure even number of legs and wings
        self.numberOfLegs = max(0, numberOfLegs % 2 == 0 ? numberOfLegs : numberOfLegs + 1)
        self.numberOfWings = max(0, numberOfWings % 2 == 0 ? numberOfWings : numberOfWings + 1)

        // Ensure not more than 8 legs and not more than 6 wings
        self.numberOfLegs = min(self.numberOfLegs, 8)
        self.numberOfWings = min(self.numberOfWings, 6)
        self.hasTail = true
    }
}

// Additional error cases for Animal
enum AnimalError: Error {
    case invalidNumberOfLegs
    case invalidNumberOfWings
    case negativeNumberOfLegs
    case cannotWalk
    case cannotFly
    case cannotSwim
}


extension String {
    func hyphenate() -> String {
        let words = self.components(separatedBy: " ")
        let hyphenatedWords = words.map { word in
            word.map { String($0) }.joined(separator: "-")
        }
        return hyphenatedWords.joined(separator: " ")
    }
}

let outputString = "this is a string".hyphenate()
print(outputString)


func makePrinter(_ strings: [String]) -> () -> Void {
    var currentIndex = 0

    return {
        guard currentIndex < strings.count else {
            print("No more elements to print.")
            return
        }

        print(strings[currentIndex])
        currentIndex += 1
    }
}

let myFunction = makePrinter(["one", "two", "three"])

myFunction()  // Output: "one"
myFunction()  // Output: "two"
myFunction()  // Output: "three"
myFunction()  // Output: "No more elements to print."


func makeRepeater(nTimes: Int) -> (String) -> Void {
    return { stringToRepeat in
        for _ in 0..<nTimes {
            print(stringToRepeat)
        }
    }
}
let myFunctionRepeat = makeRepeater(nTimes: 3)

myFunctionRepeat("Hello World")

enum ValidationError: Error {
    case invalidPassword
    case passwordNotMatch
    case otherError
}

func validate(element: String, _ validator: (String) throws -> ()) {
    do {
        try validator(element)
    } catch let error {
        if let validationError = error as? ValidationError {
            print("Validation Error: \(validationError)")
        } else {
            print("Unknown Error: \(error)")
        }
    }
}

func passwordValidator() -> (String) throws -> Void {
    return { password in
        let passwordRegex = "^[a-zA-Z0-9]{8,13}$"
        let passwordPredicate = NSPredicate(format: "SELF MATCHES %@", passwordRegex)
        
        guard passwordPredicate.evaluate(with: password) else {
            throw ValidationError.invalidPassword
        }
    }
}

// Test passwordValidator
let validPassword = "Abc12345"
let invalidPassword = "short"

validate(element: validPassword, passwordValidator()) // No output if valid
validate(element: invalidPassword, passwordValidator()) // Should print ValidationError.invalidPassword

func passwordConfirmValidator(value: @escaping @autoclosure () -> String) -> (String) throws -> Void {
    return { confirmPassword in
        let password = value()
        
        guard password == confirmPassword else {
            throw ValidationError.passwordNotMatch
        }
    }
}

// Test passwordConfirmValidator
let password = "Abc12345"
let confirmPassword = "Abc12345"
let wrongConfirmPassword = "wrongPassword"

validate(element: confirmPassword, passwordConfirmValidator(value: password)) // No output if valid
validate(element: wrongConfirmPassword, passwordConfirmValidator(value: password)) // Should print ValidationError.passwordNotMatch

import Foundation
import UIKit

struct MemberAddress: Codable {
    var address1: String
    var address2: String
    var city: String
    var country: String
    var postcode: String
}

struct MemberProfile: Codable {
    var memberSystemId: String
    var name: String
    var email: String
    var emailVerified: Bool
    var dateOfBirth: Date?
    var sequenceId: Int
    var address: MemberAddress?
    var favColor: UIColor?

    enum CodingKeys: String, CodingKey {
        case memberSystemId
        case name = "preferredName"
        case email
        case emailVerified
        case dateOfBirth
        case sequenceId
        case address = "mailingAddress"
        case favColor
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        memberSystemId = try container.decode(String.self, forKey: .memberSystemId)
        name = try container.decode(String.self, forKey: .name)
        email = try container.decode(String.self, forKey: .email)
        emailVerified = try container.decode(Bool.self, forKey: .emailVerified)
        dateOfBirth = try container.decodeIfPresent(Date.self, forKey: .dateOfBirth)
        sequenceId = try container.decode(Int.self, forKey: .sequenceId)
        address = try container.decodeIfPresent(MemberAddress.self, forKey: .address)
        favColor = try container.decodeIfPresent(String.self, forKey: .favColor).flatMap(UIColor.init(hex:))
    }
    func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)

            try container.encode(memberSystemId, forKey: .memberSystemId)
            try container.encode(name, forKey: .name)
            try container.encode(email, forKey: .email)
            try container.encode(emailVerified, forKey: .emailVerified)
            try container.encodeIfPresent(dateOfBirth, forKey: .dateOfBirth)
            try container.encode(sequenceId, forKey: .sequenceId)
            try container.encodeIfPresent(address, forKey: .address)

            if let favColor = favColor {
                let colorString = UIColor(cgColor: favColor.cgColor).hexString
                try container.encodeIfPresent(colorString, forKey: .favColor)
            }
        }
}

struct MemberProfileResponse: Codable {
    var memberProfile: MemberProfile

    static func decoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}

// Extension for UIColor creation from hex string
extension UIColor {
    convenience init?(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        
        var rgb: UInt64 = 0
        
        guard Scanner(string: hexSanitized).scanHexInt64(&rgb) else {
            return nil
        }
        
        self.init(
            red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgb & 0x0000FF) / 255.0,
            alpha: 1.0
        )
    }
    
    var hexString: String {
        let components = cgColor.components!
        let red = Float(components[0])
        let green = Float(components[1])
        let blue = Float(components[2])
        return String(format: "#%02lX%02lX%02lX", lroundf(red * 255), lroundf(green * 255), lroundf(blue * 255))
    }
}


// Sample data
let memberProfiles: [MemberProfile] = [
    // ... your MemberProfile instances
]

// Function to create NSAttributedString
func attributedString(for profiles: [MemberProfile]) -> NSAttributedString {
    let sortedProfiles = profiles.sorted { $0.sequenceId < $1.sequenceId }

    let attributedString = sortedProfiles.enumerated().reduce(NSMutableAttributedString()) { (result, enumeration) in
        let (index, profile) = enumeration
        let nameAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 16),
            .foregroundColor: profile.favColor ?? UIColor.black
        ]

        let nameAttributedString = NSAttributedString(string: profile.name, attributes: nameAttributes)
        result.append(nameAttributedString)

        if index % 2 == 1 { // Check if the index is odd (zero-based)
            let emailAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14),
                .foregroundColor: UIColor.gray
            ]

            let emailAttributedString = NSAttributedString(string: " (\(profile.email))", attributes: emailAttributes)
            result.append(emailAttributedString)
        }

        return result
    }

    return attributedString
}

let resultAttributedString = attributedString(for: memberProfiles)
print(resultAttributedString)



//func performTaskInBackgroundAndDisplay() {
//    // Use a background queue to fetch the Thing from the slow service
//    DispatchQueue.global(qos: .background).async {
//        let thing = getThingFromSlowService()
//
//        // Switch to the main queue to update the UI
//        DispatchQueue.main.async {
//            display(thing)
//        }
//    }
//}
//
//func sumAndDisplayResult() {
//    Task {
//        do {
//            let result1 = try await service1()
//            let result2 = try await service2()
//            let result3 = try await service3()
//
//            // Perform the addition
//            let totalResult = result1 + result2 + result3
//
//            // Switch to the main queue to update the UI
//            DispatchQueue.main.async {
//                print("Total Result: \(totalResult)")
//            }
//        } catch {
//            // Handle any errors
//            print("Error: \(error)")
//        }
//    }
//}

import UIKit

class BooksTableViewController: UITableViewController {

    // Data source containing information about your favorite books
    let booksData: [(title: String, author: String, birthdateOrQuote: String)] = [
        ("Book 1", "Author 1", "Birthdate or Quote 1"),
        ("Book 2", "Author 2", "Birthdate or Quote 2"),
        ("Book 3", "Author 3", "Birthdate or Quote 3"),
        ("Book 4", "Author 4", "Birthdate or Quote 4")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up the table view
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        tableView.tableFooterView = UIView() // Remove empty cells
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return booksData.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let book = booksData[indexPath.row]

        // Configure the cell
        cell.textLabel?.text = book.title
        cell.detailTextLabel?.text = book.author

        return cell
    }

    // MARK: - Table view delegate

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedBook = booksData[indexPath.row]
        let alertTitle = "Author: \(selectedBook.author)"
        let alertMessage = "Birthdate or Quote: \(selectedBook.birthdateOrQuote)"

        let alertController = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)

        present(alertController, animated: true, completion: nil)

        tableView.deselectRow(at: indexPath, animated: true)
    }
}

// Example usage:
let booksTableViewController = BooksTableViewController(style: .plain)
let navigationController = UINavigationController(rootViewController: booksTableViewController)


//import Foundation
//
//enum HTTPMethod<T: Codable> {
//    case get(T)
//    case post(T)
//    case patch(T)
//    case put(T)
//    case delete(T)
//}
//
//enum NetworkError: Swift.Error {
//    case unknown(Int)
//    // Add other error cases as needed
//}
//
//func networkResult<Request: Codable, Response: Codable, Result>(
//    endPoint: URL,
//    method: HTTPMethod<Request> = .get,
//    type: Request.Type,
//    subject: @escaping (Response) -> Result
//) async throws -> Result {
//
//    var urlRequest = try request(endPoint: endPoint, method: method)
//
//    let (data, response) = try await URLSession.shared.data(for: urlRequest)
//    guard let httpResponse = response as? HTTPURLResponse else { throw NetworkError.unknown(ErrorCode.unknown.rawValue) }
//
//    if (200..<300).contains(httpResponse.statusCode) || httpResponse.statusCode == 204 {
//        // Decode the JSON response for successful requests (status code 200-299 or 204)
//        let decodedResponse = try JSONDecoder().decode(Response.self, from: data)
//        return subject(decodedResponse)
//    } else if (400..<500).contains(httpResponse.statusCode) {
//        // Decode the JSON body of the error response for client errors (status code 4xx)
//        let errorResponse = try JSONDecoder().decode(ErrorResponse.self, from: data)
//        throw NetworkError.unknown(errorResponse.errorCode)
//    } else {
//        throw NetworkError.unknown(ErrorCode.unknown.rawValue)
//    }
//}
//
//struct ErrorResponse: Codable {
//    let errorCode: Int
//    // Add other properties as needed
//}
//
//func request<Request: Codable>(endPoint: URL, method: HTTPMethod<Request>) throws -> URLRequest {
//    var urlRequest = URLRequest(url: endPoint)
//    urlRequest.httpMethod = methodString(method)
//
//    switch method {
//    case .get, .delete:
//        // Handle GET and DELETE methods with URL parameters if needed
//        break
//    case .post(let body), .put(let body), .patch(let body):
//        // Handle POST, PUT, and PATCH methods with JSON body
//        urlRequest.httpBody = try JSONEncoder().encode(body)
//        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
//    }
//
//    return urlRequest
//}
//
//func methodString<T>(_ method: HTTPMethod<T>) -> String {
//    switch method {
//    case .get: return "GET"
//    case .post: return "POST"
//    case .patch: return "PATCH"
//    case .put: return "PUT"
//    case .delete: return "DELETE"
//    }
//}
